package com.capgemini.bankapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.bankapp.exception.CustomerException;
import com.capgemini.bankapp.model.Customer;
import com.capgemini.bankapp.service.ICustomerService;
@Controller
@RequestMapping(value="/bank")
public class CustomerController {
	@Autowired
	ICustomerService customerService;

	//For displaying the main menu
	@RequestMapping(value="/mainmenu")
	public String getCustomerMenu() {
		return "main_menu";
	}


	/*Create an account*/
	@RequestMapping(value="/preregister" ,method=RequestMethod.GET)
	public ModelAndView customerForm() {
		Customer customer=new Customer();
		return new ModelAndView("apply","customer",customer);
	}
	@RequestMapping(value="/register" ,method=RequestMethod.POST)
	public ModelAndView addCustomer( @ModelAttribute(value="customer")Customer customer) 
	{
		try {
			
				Integer accNum=customerService.createAccount(customer);
				if(accNum!=0)
				{
				return new ModelAndView("customer_creation","accountNumber",accNum);
				}
					else
				{
				String result="Account creation failed.!Sorry Try again";
				return new ModelAndView("status","message",result); 

				}
		} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		
	}
	//To display the other services
	@RequestMapping(value="/services")
	public String getServicesmenu() {
		return "services";
	}
										//Show the balance
		//To display the withdrawal form
	@RequestMapping(value="/showbalance")
	public String show_balance(Model model)
	{
		
	 model.addAttribute("customer", new Customer()); 
		return "show_balance";
	}


		//To get the account number,pin from the form
	@RequestMapping(value="tocontroller" ,method=RequestMethod.POST)
	public ModelAndView show_balance( @RequestParam(value="accNum") Integer accNum,@RequestParam(value="pin")Integer pin)
	{
		try
		{
			double balance=customerService.showBalance(accNum, pin);
			return new ModelAndView("display_pg","balance",balance);
		} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		

	}



											//Withdrawal
	//To display the withdrawal form
	@RequestMapping(value="/withdraw")
	public String withdrawForm(Model model)
	{
		 model.addAttribute("customer", new Customer()); 
		return "withdraw";
	}


	//To get the account number,pin,amount from the form
	@RequestMapping(value="fromwith" ,method=RequestMethod.POST)
	public ModelAndView withdrawal( @RequestParam(value="accNum") Integer accNum,
			@RequestParam(value="pin")Integer pin,@RequestParam(value="amt")Double amt)
	{
		try
		{
			double balance=customerService.withDraw(accNum, pin, amt);
			return new ModelAndView("display_pg","balance",balance);
		} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		

	}
												/*	Deposit*/
	//To display the deposit form
	@RequestMapping(value="/deposit")
	public String depositForm(Model model)
	{
	model.addAttribute("customer", new Customer()); 
	return "deposit";											
		
	}


	//To get the account number,pin,amount from the form
	@RequestMapping(value="fromdep" ,method=RequestMethod.POST)
	public ModelAndView deposit( @RequestParam(value="accNum") Integer accNum,
			@RequestParam(value="pin")Integer pin,@RequestParam(value="amt")Double amt)
	{
		try
		{
			double balance=customerService.deposit(accNum, pin, amt);
			return new ModelAndView("display_pg","balance",balance);
		} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		

	}
	/*Fund transfer*/
	//To display the fund transfer form	
	@RequestMapping(value="/fundtransfer")
	public String fundtransferForm(Model model)
	{
		 model.addAttribute("customer", new Customer()); 
		return "fund_transfer";
	}

	@RequestMapping(value="fromft" ,method=RequestMethod.POST)
	public ModelAndView fundTransfer( @RequestParam(value="accNum") Integer accNum,
			@RequestParam(value="pin")Integer pin,@RequestParam(value="amt")Double amt,@RequestParam(value="funacc")Integer funacc)	
	{
		try {

			boolean flag=customerService.fundTransfer(accNum, funacc, amt, pin);
			if(flag)
			{
				String result="Fund Transfer is successful.!!";
				return new ModelAndView("status","message",result); 
			}else
			{
				String result="Fund Transfer failed.!Sorry Try again";
				return new ModelAndView("status","message",result); 
			} 
		}catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		
	}

}

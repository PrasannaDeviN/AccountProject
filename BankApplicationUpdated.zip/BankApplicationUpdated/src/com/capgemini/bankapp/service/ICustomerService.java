package com.capgemini.bankapp.service;

import com.capgemini.bankapp.exception.CustomerException;
import com.capgemini.bankapp.model.Customer;

public interface ICustomerService {
	public Integer createAccount(Customer customer)throws CustomerException;
	public double showBalance(Integer accNum, Integer pin)throws CustomerException;
	public double withDraw(Integer accNum,Integer pin,Double amt)throws CustomerException;
	public double deposit(Integer accNum,Integer pin,Double amt)throws CustomerException;
	
	public boolean fundTransfer(Integer accNum,Integer funacc,Double amt,Integer pin)throws CustomerException;
/*	public String printTransaction(Integer accNum,Integer pin)throws CustomerException;*/
	
}

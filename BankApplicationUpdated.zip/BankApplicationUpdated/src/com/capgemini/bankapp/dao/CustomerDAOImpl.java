package com.capgemini.bankapp.dao;


import java.util.InputMismatchException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.bankapp.entity.CustomerEntity;
import com.capgemini.bankapp.exception.CustomerException;




@Repository


public class CustomerDAOImpl implements ICustomerDao
{
	double balance;
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Integer createAccount(CustomerEntity customerEntity)throws CustomerException
	{
		//To create a new account
		try
		{
			entityManager.persist(customerEntity);
			return customerEntity.getAccNum();
		}catch(PersistenceException e) {
			throw new CustomerException(e.getMessage());
		}		
	}


	@Override
	public double showBalance(Integer accNum, Integer pin)throws CustomerException
	{
		try{
			CustomerEntity customerE=entityManager.find(CustomerEntity.class,accNum);
			if(customerE.getPin().intValue()==pin.intValue())
				balance=customerE.getBalance();
			return balance;
		}catch(Exception e) {

			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}
	}
	@Override
	public double withDraw(Integer accNum,Integer pin,Double amt)throws CustomerException
	{	

		try{
			CustomerEntity customerE=entityManager.find(CustomerEntity.class,accNum);
			//To withdraw from the current balance
			if(customerE.getPin().intValue()==pin.intValue())
			{
				//To withdraw from the current balance
				customerE.setBalance(customerE.getBalance()- amt);
				String status=customerE.getStatus().concat("\n Withdraw of Rs."+amt+"is performed");
				customerE.setStatus(status);
				entityManager.merge(customerE);
				return customerE.getBalance();
			}else
				return 0;

		}catch(InputMismatchException e) 
		{

			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}

	}
	@Override
	public double deposit(Integer accNum,Integer pin,Double amt)throws CustomerException

	{

		try{

			CustomerEntity customerE=entityManager.find(CustomerEntity.class,accNum);
			if(customerE.getPin().intValue()==pin.intValue())
			{
				customerE.setBalance(customerE.getBalance() + amt);//To update the balance
				String status=customerE.getStatus().concat("\n Deposit of Rs."+amt+"\tis performed\n");
				customerE.setStatus(status);
				entityManager.merge(customerE);
				return customerE.getBalance();
			}else
			{
				return 0;
			}
		}
		catch(InputMismatchException e) 
		{
			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}
	}
	@Override
	public boolean fundTransfer(Integer accNum,Integer funacc,Double amt,Integer pin)throws CustomerException
	{

		try
		{
			double newBalance=0;

			//To withdraw from first account
			CustomerEntity customerE = entityManager.find(CustomerEntity.class, accNum);
			if(customerE.getPin().intValue()==pin.intValue())
			{
				balance = customerE.getBalance();
				if(balance>=amt)
					newBalance=customerE.getBalance()-amt;
				customerE.setBalance(newBalance);
				String status=customerE.getStatus().concat("\n Sent Rs."+amt+"\t to\t"+funacc);
				customerE.setStatus(status);

				//To deposit to second account
				CustomerEntity customerEn = entityManager.find(CustomerEntity.class,funacc);
				newBalance = customerEn.getBalance()+amt; 
				customerEn.setBalance(newBalance);
				String status1=customerEn.getStatus().concat("\n Received Rs."+amt+"\t from \t"+accNum);
				customerEn.setStatus(status1);
				entityManager.merge(customerE);
				entityManager.merge(customerEn);
				
				return true;
			}
			else {
				return false;
			}

		}
		catch(InputMismatchException e)
		{
			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}

	}
	@Override
	public boolean validateBalance(Integer accNum,Integer pin,Double amt)throws CustomerException
	{
		//To check for minimum balance
		try{

			CustomerEntity customerE=entityManager.find(CustomerEntity.class,accNum);
			customerE.getBalance();
			if(customerE.getPin().intValue()==pin.intValue()&&(customerE.getBalance()>=amt))
			{
				return true;
			}else
			{
				return false;

			}

		}catch(Exception e) 
		{

			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}
	}


//	@Override
//	public String printTransaction(Integer accNum,Integer pin)throws CustomerException
//	{
//
//		try{
//
//			CustomerEntity customerE=entityManager.find(CustomerEntity.class,accNum);
//			if(customerE.getPin().intValue()==pin.intValue())
//			{
//				return customerE.getStatus();
//			}
//			return "Invalid attempt";
//		}catch(Exception e) {
//			throw new CustomerException(e.getMessage());
//		}finally
//		{
//			entityManager.close();
//		}
//
//	}
}


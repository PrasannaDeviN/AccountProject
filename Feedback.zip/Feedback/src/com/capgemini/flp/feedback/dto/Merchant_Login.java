package com.capgemini.flp.feedback.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="merchant_login")
public class Merchant_Login {
@Id
private String email_Id;
private String password;
private String name;
private String phoneNumber;
private String address;
@Column(name="Organization_name")
private String organizationName;
public  Merchant_Login(){
	
}
public String getEmail_Id() {
	return email_Id;
}
public void setEmail_Id(String email_Id) {
	this.email_Id = email_Id;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getOrganizationName() {
	return organizationName;
}
public void setOrganizationName(String organizationName) {
	this.organizationName = organizationName;
}
public Merchant_Login(String email_Id, String password, String name,
		String phoneNumber, String address, String organizationName) {
	super();
	this.email_Id = email_Id;
	this.password = password;
	this.name = name;
	this.phoneNumber = phoneNumber;
	this.address = address;
	this.organizationName = organizationName;
}

}

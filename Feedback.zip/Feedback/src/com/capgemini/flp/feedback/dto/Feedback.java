package com.capgemini.flp.feedback.dto;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
public class Feedback {
private String seller_emailId;
private String product_feedback;
private String product_Rating;
private String customerFeedBackToSeller;
private String sellerResponseToCustomer;
private String customer_emailId;
private String prod_Id;

public  Feedback() {
	
}

public String getSeller_emailId() {
	return seller_emailId;
}

public void setSeller_emailId(String seller_emailId) {
	this.seller_emailId = seller_emailId;
}

public String getProduct_feedback() {
	return product_feedback;
}

public void setProduct_feedback(String product_feedback) {
	this.product_feedback = product_feedback;
}

public String getProduct_Rating() {
	return product_Rating;
}

public void setProduct_Rating(String product_Rating) {
	this.product_Rating = product_Rating;
}

public String getCustomerFeedBackToSeller() {
	return customerFeedBackToSeller;
}

public void setCustomerFeedBackToSeller(String customerFeedBackToSeller) {
	this.customerFeedBackToSeller = customerFeedBackToSeller;
}

public String getSellerResponseToCustomer() {
	return sellerResponseToCustomer;
}

public void setSellerResponseToCustomer(String sellerResponseToCustomer) {
	this.sellerResponseToCustomer = sellerResponseToCustomer;
}

public String getCustomer_emailId() {
	return customer_emailId;
}

public void setCustomer_emailId(String customer_emailId) {
	this.customer_emailId = customer_emailId;
}

public String getProd_Id() {
	return prod_Id;
}

public void setProd_Id(String prod_Id) {
	this.prod_Id = prod_Id;
}

public Feedback(String seller_emailId, String product_feedback,
		String product_Rating, String customerFeedBackToSeller,
		String sellerResponseToCustomer, String customer_emailId, String prod_Id) {
	super();
	this.seller_emailId = seller_emailId;
	this.product_feedback = product_feedback;
	this.product_Rating = product_Rating;
	this.customerFeedBackToSeller = customerFeedBackToSeller;
	this.sellerResponseToCustomer = sellerResponseToCustomer;
	this.customer_emailId = customer_emailId;
	this.prod_Id = prod_Id;
}


}

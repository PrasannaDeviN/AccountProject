package com.capgemini.flp.feedback.dto;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="customer_login")
public class Customer_Login {
private String email_Id;
private String password;
private String name;
private String phoneNumber;
private String address;

public Customer_Login()
{
	
}
public String getEmail_Id() {
	return email_Id;
}
public void setEmail_Id(String email_Id) {
	this.email_Id = email_Id;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Customer_Login(String email_Id, String password, String name,
		String phoneNumber, String address) {
	super();
	this.email_Id = email_Id;
	this.password = password;
	this.name = name;
	this.phoneNumber = phoneNumber;
	this.address = address;
}


}

package com.capgemini.flp.feedback.dao;

public class ImplDAO {

}

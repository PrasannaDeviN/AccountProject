package com.capgemini.flp.feedback.dao;

public interface IntDAO {

}

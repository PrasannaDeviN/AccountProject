package com.capgemini.flp.feedback.service;

public interface IntService {

}

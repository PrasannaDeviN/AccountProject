package com.capgemini.flp.feedback.myexception;

public class ProductException {

}

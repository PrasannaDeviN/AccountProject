package com.cg.empapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

public class EmployeeDao implements EmployeeDaoInt {
@PersistenceContext
EntityManager entityManager;
	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		
		try{
		
		TypedQuery<Employee> query=entityManager.createQuery("from Employee",Employee.class);
		
		return query.getResultList();
	}catch(Exception e){
		throw new EmployeeException(e.getMessage());
	}

	
	
	
}
}

package com.cg.empapp.dao;

import java.util.List;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

public interface EmployeeDaoInt {
	List<Employee> getEmployees() throws EmployeeException; 
}

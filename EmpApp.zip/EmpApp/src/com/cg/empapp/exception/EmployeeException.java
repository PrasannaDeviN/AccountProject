package com.cg.empapp.exception;

public class EmployeeException extends Exception {
String message;
public EmployeeException(String message)
{
	this.message=message;
}
}

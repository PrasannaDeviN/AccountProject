package Service;

import Dao.DaoImp;


import java.util.regex.Matcher;
import java.util.regex.Pattern; 
import Client.BankClient;


public class ServImp implements ServiceInt {
DaoImp d= new DaoImp();
	
	public int createAccount(BankClient bean)  {
		// TODO Auto-generated method stub
		
       return d.createAccount(bean);
	}
	public boolean isName(String cname)
	{
		boolean flag=false;
		Pattern pn=Pattern.compile("^[a-zA-Z\\s]*$");
		Matcher mn=pn.matcher(cname);
		if(mn.matches())
		{
			flag=true;
			System.out.println("valid name");
		}
		else
		{
			System.out.println("enter valid name");
		}
		return flag;
		
	}
	public boolean isAddress(String address)
	{
		boolean flag=false;
		Pattern pa=Pattern.compile("(?=,*[0-9])[A-Za-z0-9,\\s]+");
		Matcher ma=pa.matcher(address);
		if(ma.matches())
		{
			System.out.println("matches");
			flag=true;
		}
		else
		{
			System.out.println("Invalid address!! Enter valid address");
		}
		return flag;
	}
	public boolean isPhn(String phNum)
	{
		boolean flag=false;
		Pattern pp=Pattern.compile("^[6-9][0-9]{9}$");
		Matcher mp=pp.matcher(phNum);
		if(mp.matches()) {
			flag=true;
		}
		else 
		{
			System.out.println("Invalid Phone number!! Enter valid phone number");
			 flag=false;
		}
		return flag;
		}
	public boolean isPan(String panNum)
	{
		boolean flag=false;
		Pattern ppan=Pattern.compile("^[0-9A-Z]{10}$");
		Matcher mpan=ppan.matcher(panNum);
		if(mpan.matches()) {
			flag=true;
		}
		else 
		{
			System.out.println("Invalid Pan number!! Enter valid pan number");
			 flag=false;
		}
		return flag;
		}
	                                                                                                                                     
	
	public double showBalance(int id)  {
		// TODO Auto-generated method stub
		return d.showBalance(id);
        
	}

	 
	
	public double deposit(int id,double deposit)  {
		// TODO Auto-generated method stub
       return d.deposit(id, deposit);
	}

	
	
	
	 

	@Override
	public double withdraw(int id,double withdraw){
		// TODO Auto-generated method stub
		return d.withdraw(id, withdraw);
		
	}

	public double fundTransfer(int id,int id1, double fund){
	// TODO Auto-generated method stub
  return d.fundTransfer(id,id1,fund);
}


	/*@Override
	public void printTransactions(BankClient bean) {
		// TODO Auto-generated method stub
		
	}
*/
}

package Service;

import Client.BankClient;


public interface ServiceInt {
	public int createAccount(BankClient bean);
	public double showBalance(int id);
	public double withdraw(int id,double withdraw);
	public double deposit(int id,double deposit);
	public double fundTransfer(int id, int id1, double fund);
	//public void printTransactions(BankClient bean);
}

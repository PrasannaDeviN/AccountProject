package Client;

public class BankClient {

	String cname;
	String address;
	String phNum;
	String panNum;
	public int accNum;
	public double balance;

	public BankClient() {

	}

	public int getAccNum() {
		return accNum;
	}

	public void setAccNum(int accNum) {

		this.accNum=accNum;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhNum() {
		return phNum;
	}

	public void setPhNum(String phNum) {
		this.phNum = phNum;
	}

	public String getPanNum() {
		return panNum;
	}

	public void setPanNum(String panNum) {
		this.panNum = panNum;
	}

	@Override
	public String toString() {
		return "Client [cname=" + cname + ", address=" + address + ", phNum=" + phNum + ", panNum=" + panNum + "]";
	}

}

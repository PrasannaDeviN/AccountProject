package XYZBank;

//import java.util.HashMap;
import exceptions.Myexception;
import java.util.Scanner;

import Client.BankClient;
import Service.ServImp;

public class Bank {

	public static void main(String[] args) throws Myexception{
try {
		// TODO Auto-generated method stub
		ServImp s = new ServImp();
		BankClient bean = new BankClient();
		
		Bank b = new Bank();
		while (true) {
			System.out.println("Welcome to XYZ Bank");
			System.out.println("1. CREATE ACCOUNT ");
			System.out.println("2. SHOW BALANCE");
			System.out.println("3. DEPOSIT");
			System.out.println("4. WITHDRAW");
			System.out.println("5. FUND TRANSFER");
			System.out.println("6. PRINT TRANSACTION");
			System.out.println("7. EXIT");
			Scanner sc = new Scanner(System.in);
			Scanner sc2 = new Scanner(System.in);
			int choice = sc.nextInt();
			boolean flag;
			switch (choice) {
			case 1:
               
				do
				{
				System.out.println("enter name");
				String cname = sc2.nextLine();
				flag=(s.isName(cname));
				}
				while(flag==false);
				do
				{
				System.out.println("enter address");
				String address = sc.next();
				flag=(s.isAddress(address));
				}while(flag==false);
				
				do
				{
				System.out.println("enter PHONE num");
				String phNum =sc.next();
				flag=s.isPhn(phNum);
				}while(flag==false);
				do {
				System.out.println("enter PAN number");
				String panNum = sc.next();
				flag=(s.isPan(panNum));
				}while(flag==false);
				break;
                

			case 2:
				
				System.out.println("enter account number");
				int id = sc.nextInt();
				System.out.println(s.showBalance(id));
				break;
               
			case 3:
				
				System.out.println("enter the acc number");
				int id2 = sc.nextInt();
				System.out.println("enter the amount to be deposited");
				double deposit = sc.nextDouble();
				System.out.println(s.deposit(id2, deposit));
				break;
			case 4:
				
				System.out.println("enter acc number");
				int id3=sc.nextInt();
				System.out.println("enter the amount to be withdrawn");
				double withdraw=sc.nextDouble();
				System.out.println(s.withdraw(id3, withdraw));
				break;
			case 5:
				
				System.out.println("enter your acc number");
				int id4=sc.nextInt();
				System.out.println("enter beneficiary acc number");
				int id5=sc.nextInt();
				System.out.println("enter the amount to be transfered");
				double fund=sc.nextDouble();
				System.out.println(s.fundTransfer(id4,id5,fund));
				break;
			default:
				System.out.println("wrong choice");
				break;
				
			}
			
		}
			}catch(Exception me) {
				System.out.println("\n The exception is"+me.getMessage());
	}
}
}
	

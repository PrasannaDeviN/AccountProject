package Dao;

import java.util.HashMap;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import Client.BankClient;




public class DaoImp implements DaoInt {
	
	//BankClient bean= new BankClient();
	Map<Integer,BankClient> cm=new HashMap<Integer,BankClient>();
	
	int accNum=100;
	public int createAccount(BankClient bean) {
		bean.setAccNum(accNum);
        cm.put(bean.getAccNum(),bean);
        accNum++;
        return bean.accNum;
       
     
       }

	
	public double showBalance(int id){
		Set<Integer> key=cm.keySet();
		Iterator<Integer> it=key.iterator();
			    
		while(it.hasNext())
		{
			Integer accNum= it.next();
			if(accNum==id)
			{
			BankClient cus=cm.get(accNum);
			System.out.println(cus);
			return cus.balance;
			
			}
		}
		return 0;

	}

	@Override
	public double deposit(int id,double deposit) {
		Set<Integer> key=cm.keySet();
		Iterator<Integer> it=key.iterator();
	    
		while(it.hasNext())
		{
			Integer accNum=it.next();
			if(accNum==id)
			{
				BankClient cus=cm.get(accNum);
				cus.balance+=deposit;
				cm.put(accNum,cus);
				
		       return cus.balance;
			}
		}
		return 0;
	}

	
	@Override
	public double withdraw(int id, double withdraw ) 
	{
		double d=0;
		
		Set<Integer> key=cm.keySet();
		Iterator<Integer> it=key.iterator();
		while(it.hasNext())
		{
			Integer accNum=it.next();
			if(accNum==id)
			{
				BankClient cus=cm.get(accNum);
				
				if(withdraw>cus.balance)
				{
					System.out.println("insufficient balance");
					d=0;
				}
				else
				{
					cus.balance-=withdraw;
					cm.put(accNum,cus);
					d=cus.balance;
				}
			}
		
		}	
		return d;
	}

	@Override
	public double fundTransfer(int id,int id1, double fund){
		double d=0,l=0;
		Set<Integer> key=cm.keySet();
		Iterator<Integer> it=key.iterator();
		while(it.hasNext())
		{
			Integer accNum=it.next();
			if(accNum==id)
			{
				BankClient cus=cm.get(accNum);
				
				if(fund>cus.balance)
				{
					System.out.println("insufficient balance");
					
				}
				else
				{
					cus.balance-=fund;
					cm.put(accNum,cus);
					d=cus.balance;
				}
			}
		
		}	
		
	
	Set<Integer> key1=cm.keySet();
	Iterator<Integer> it1=key1.iterator();
    
	while(it1.hasNext())
	{
		
		Integer accNum=it1.next();
		if(accNum==id1)
		{
			BankClient cus=cm.get(accNum);
			cus.balance+=fund;
			cm.put(accNum,cus);
			l=cus.balance;
			System.out.println("a sum of amount" +l+ "is transfered from acc num "+id+"to the acc num "+id1);
	       
		}
	}
	return l;
		
        
}



	//@Override
	//public void printTransactions(BankClient bean) {
		// TODO Auto-generated method stub
        
	}



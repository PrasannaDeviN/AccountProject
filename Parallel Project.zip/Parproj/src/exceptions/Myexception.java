package exceptions;

public class Myexception extends Exception {
	Myexception()
	{
		super();
	}
	Myexception(String message)
	{
		super(message);
	}
}

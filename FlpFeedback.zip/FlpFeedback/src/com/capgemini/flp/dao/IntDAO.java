package com.capgemini.flp.dao;

import com.capgemini.flp.dto.Customer_Login;
import com.capgemini.flp.dto.Feedback;

public interface IntDAO {

	public Feedback getFeedbackPage(Feedback feedback);
	

}

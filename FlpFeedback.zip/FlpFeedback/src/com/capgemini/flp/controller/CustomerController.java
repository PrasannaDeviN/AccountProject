package com.capgemini.flp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Customer_Login;
import com.capgemini.flp.dto.Feedback;
import com.capgemini.flp.service.IntService;



@Configuration
@Controller
public class CustomerController {
   @Autowired 
   IntService service;
	@RequestMapping(value="/fb")
	public ModelAndView getFeedbackPage(@RequestParam("product_Id")@ModelAttribute("feedb") Feedback feedback)
	{
		System.out.println("hi");
		System.out.println(feedback);
		Feedback feed=service.getFeedbackPage(feedback);
		
		return new ModelAndView("feedback","data",feed);
		
	}
	
}

package com.capgemini.doctors.Service;
import com.capgemini.doctors.Bean.*;
import com.capgemini.doctors.Dao.DoctorAppointmentDao;


public interface IDoctorApointmentService {
	

	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment);
	DoctorAppointment getAppointmentDetails(int appointmentId);
}

package com.capgemini.doctors.Service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.doctors.Bean.DoctorAppointment;
import com.capgemini.doctors.Dao.DoctorAppointmentDao;



public class DoctorAppointmentService implements IDoctorApointmentService {
	DoctorAppointmentDao dad= new DoctorAppointmentDao();
	//validating name
	public boolean validName(String patientName){
		boolean flag=false;
		Pattern pname=Pattern.compile("^[A-Z][A-Za-z, \\s");
		Matcher mname=pname.matcher(patientName);
		if(mname.matches()){
			
			flag=true;
		}
		
		else{
			flag=false;
		}
		return flag;
	}
	
	//validating phone number
	public boolean validPhone(String phoneNumber){
		boolean flag=false;
		Pattern pphone=Pattern.compile("^[6-9][0-9]{9}");
		Matcher mphone=pphone.matcher(phoneNumber);
		if( mphone.matches()){
			
			flag=true;
		}
		
		else{
			flag=false;
		}
		return flag;
	}
	
	//validating email
	public boolean validEmail(String email){
		boolean flag=false;
		Pattern pemail=Pattern.compile("^[A-Za-z]A-Za-z0-9@.");
		Matcher memail=pemail.matcher(email);
		if( memail.matches()){
			
			flag=true;
		}
		
		else{
			flag=false;
		}
		return flag;
	}
	
	//validating gender
	public boolean validGender(String gender){
		boolean flag=false;
		String g1="male";
		String g2="female";
		if(gender==g1||gender==g2)
		{
			flag=true;
		}
		else{
			flag=false;
		}
		return flag;
	}
	
	//validating age
	public boolean validAge(int age){
		boolean flag=false;
		if(age>0){
			
			flag=true;
		}
		else{
			flag=false;
		}
		return flag;
	}
	
	//validating problem name
	
	public boolean validProblemName(String problemName){
		
     
	String p1="Heart", p2="Gynecology", p3="Diabetes", p4="ENT", p5="Bone", p6="Dermatology";
	String flag="DISAPPROVED";
	if(p1.equalsIgnoreCase(problemName)||p2.equalsIgnoreCase(problemName)||p3.equalsIgnoreCase(problemName)||p4.equalsIgnoreCase(problemName)||p5.equalsIgnoreCase(problemName)||p6.equalsIgnoreCase(problemName))
	{
		flag="APPROVED. /n/n YOUR DOCTOR DETAILS WILL BE SHARED SHORTLY!";
	}
	else{
		flag="DISAPPROVED";
	}
		return flag;
	}	
		
		
		
		
		
		
		
		
		
		
		
		
		
	public boolean addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
	{
		
		
	    
		return dad.addDoctorAppointmentDetails(doctorAppointment);
	}	
	
	public DoctorAppointment getAppointmentDetails(int appointmentId) {
		
return dad.getAppointmentDetails( appointmentId);

	
		
	}
}

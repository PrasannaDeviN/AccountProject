package com.capgemini.doctors.Exceptions;

public class Myexception extends Exception{
Myexception(){
	super();
}
Myexception(String message)
{
	super(message);
}
}

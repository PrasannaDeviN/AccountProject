package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.Bean.DoctorAppointment;
import com.capgemini.doctors.Service.DoctorAppointmentService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       DoctorAppointment doctorAppointment=new  DoctorAppointment();
       DoctorAppointmentService das=new DoctorAppointmentService();
       Scanner sc=new Scanner(System.in);
       while(true)
       {
    	   System.out.println("Doctor Appointment Service Provider Portal");
    	   System.out.println("1. Book Doctor Appointment");
    	   System.out.println("2. View Doctor Appointnment");
    	   System.out.println("3. Exit");
    	   int choice;
    	   choice=sc.nextInt();
    	   switch(choice) {
    	   case 1:
    		  
    		   System.out.println("Enter Name of the patient   :");
    		   String patientName=sc.nextLine();
    		   
    		   System.out.println("Enter Phone Number   :");
    		   String phoneNumber=sc.nextLine();
    		   
    		   System.out.println("Enter Email   :");
    		   String email=sc.nextLine();
    		   
    		   System.out.println("Enter Age   :");
    		   int age=sc.nextInt();
    		   
    		   System.out.println("Enter Gender   :");
    		   String gender=sc.nextLine();
    		   
    		   System.out.println("Enter Problem Name   :");
    		   String problemName=sc.nextLine();
    		   
    		   
    		   doctorAppointment.setPatientName(patientName);
    		   doctorAppointment.setPhoneNumber(phoneNumber);
    		   doctorAppointment.setEmail(email);
    		   doctorAppointment.setAge(age);
    		   doctorAppointment.setGender(gender);
    		   doctorAppointment.setProblemName(problemName);
    		   
    		   
    		 
			int appointmentId;
			das.addDoctorAppointmentDetails(doctorAppointment);
    		   break;
    		  
    		   
    	   case 2:
    		  
 
    		   
    		   System.out.println("Enter the appointment id ");
    		   int appointmentId2=sc.nextInt();
    		   doctorAppointment.setAppointmentId(appointmentId2);
    		   break;
    		   
    		   
    		   
    		   
    		   
    	   case 3:
    		   System.out.println("exit");
    		   System.exit(0);
    		   break;
    		   
    		default:
    			System.out.println("no choice");
    		   break;
    		   
    		   
    		   
    	   }
       }
       
	}


}
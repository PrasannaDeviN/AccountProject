package com.capgemini.doctors.Dao;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.Bean.DoctorAppointment;
import com.capgemini.doctors.Exceptions.Myexception;


public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	public static Map<Integer, DoctorAppointment> hm =new HashMap<Integer, DoctorAppointment>();
	int appointmentId;
	
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)	{
		doctorAppointment.setAppointmentId(appointmentId);
		hm.put(doctorAppointment.getAppointmentId(), doctorAppointment);
		return appointmentId;
	}


	public DoctorAppointment getAppointmentDetails(int appointmentId) {
		
		DoctorAppointment d2=new DoctorAppointment();
		for(DoctorAppointment d:hm.values())
		{
			if(d.getAppointmentId() == appointmentId )
			{
				d2=d;
			}
			
		}
		
		return d2;
	}
		
		

}


package com.capgemini.doctors.Dao;

import com.capgemini.doctors.Bean.DoctorAppointment;
import com.capgemini.doctors.Exceptions.*;

public interface IDoctorAppointmentDao {
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws Myexception;
	DoctorAppointment getAppointmentDetails(int appointmentId);
	}


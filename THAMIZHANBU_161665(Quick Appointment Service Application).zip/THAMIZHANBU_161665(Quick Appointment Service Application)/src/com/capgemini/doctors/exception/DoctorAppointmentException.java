package com.capgemini.doctors.exception;

public class DoctorAppointmentException extends Exception {

	public DoctorAppointmentException(String exceptionMessage) {
		
		super(exceptionMessage);
	}
}

package com.capgemini.timesheet.exception;

public class AuditorException extends Exception  {

	private static final long serialVersionUID = 1L;
	public String message;
	public AuditorException(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
	
	
	
	
	
	
	
	
	
	
}

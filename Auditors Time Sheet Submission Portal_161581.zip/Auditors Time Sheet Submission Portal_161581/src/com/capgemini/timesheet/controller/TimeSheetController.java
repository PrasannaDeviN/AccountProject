package com.capgemini.timesheet.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.timesheet.entity.Client;
import com.capgemini.timesheet.exception.AuditorException;
import com.capgemini.timesheet.service.ITimeSheetService;


@Controller
public class TimeSheetController {
    
	// url for home page display
	@Autowired
	ITimeSheetService service;
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String home(){
			return "home";
			}
	
	//url for  activities drop down list 
	@RequestMapping(value="/timesheet")
	public ModelAndView timesheet(@ModelAttribute("ats") Client client, Map<String,Object> map)throws AuditorException{
		
		//List creation for activity drop down list
		List<String> list=new ArrayList<>();
		list.add("--Select--");
	    list.add("DATA_ENTRY");
	    list.add("ACCOUNTS_TALLY");
	    list.add("LEDGER_POSTINGS");
	    list.add("BALANCE_SHEET");
	    list.add("RETURNS_FILING");
		map.put("activity", list);
		Date date = new Date();  
	    
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	      String strgDate= formatter.format(date);  
	    System.out.println(strgDate);  
			return new ModelAndView("timesheet", "date", strgDate);
	}
	
	//url for displaying the success page
	@RequestMapping(value="/success",method=RequestMethod.POST)
	public ModelAndView timeSheetSubmission(@ModelAttribute("ats") Client client) throws AuditorException{ 
		client.getTsDate();
		Integer id=service.timeSheetSubmission(client);
		
		
		return new ModelAndView("success", "data", id);
	}
	
}

package com.capgemini.timesheet.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.stereotype.Repository;

import com.capgemini.timesheet.entity.Client;
import com.capgemini.timesheet.exception.AuditorException;


@Repository
public class TimeSheetDAOImpl implements ITimeSheetDAO {

	
	@PersistenceContext
	//entitymanager object creation
	EntityManager entityManager; 

	@Override
	public Integer timeSheetSubmission(Client client)throws AuditorException {
		try 
		{
		entityManager.persist(client);
		entityManager.flush();
		return client.gettId();
	}catch(PersistenceException e)
	{
		throw new AuditorException(e.getMessage());
	}
}
}

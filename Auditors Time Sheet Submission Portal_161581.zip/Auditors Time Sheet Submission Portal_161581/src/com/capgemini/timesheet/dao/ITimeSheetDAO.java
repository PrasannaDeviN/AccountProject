package com.capgemini.timesheet.dao;

import com.capgemini.timesheet.entity.Client;
import com.capgemini.timesheet.exception.AuditorException;

public interface ITimeSheetDAO {
	
	public Integer timeSheetSubmission(Client client) throws AuditorException;
	
}

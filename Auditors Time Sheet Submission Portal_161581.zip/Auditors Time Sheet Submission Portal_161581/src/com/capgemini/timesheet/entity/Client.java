package com.capgemini.timesheet.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;


@Entity
@Table(name="client")
public class Client {
	@Id
	@Column(name="timesheet_id")
	@GeneratedValue(strategy=GenerationType.AUTO) 
	private Integer tId;
	
	@Column(name="emp_id")
	@Pattern(regexp="^[A-Z]{3}+[0-9]{5}$")  //pattern for employee id
	private String empId;
	
	@Column(name="timesheet_date")
	private Date tsDate;
	
	@Column(name="first_hour")
	private String hourOne;
	
	@Column(name="second_hour")
	private String hourTwo;
	
	@Column(name="third_hour")
	private String hourThree;
	
	@Column(name="fourth_hour")
	private String hourFour;
	
	@Column(name="fifth_hour")
	private String hourFive;
	
	@Column(name="sixth_hour")
	private String hourSix;
	
	@Column(name="seventh_hour")
	private String hourSeven;
	
	@Column(name="eighth_hour")
	private String hourEight;

	public Integer gettId() {
		return tId;
	}

	public void settId(Integer tId) {
		this.tId = tId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public Date getTsDate() {
		return tsDate;
	}

	public void setTsDate(Date tsDate) {
		this.tsDate = tsDate;
	}

	public String getHourOne() {
		return hourOne;
	}

	public void setHourOne(String hourOne) {
		this.hourOne = hourOne;
	}

	public String getHourTwo() {
		return hourTwo;
	}

	public void setHourTwo(String hourTwo) {
		this.hourTwo = hourTwo;
	}

	public String getHourThree() {
		return hourThree;
	}

	public void setHourThree(String hourThree) {
		this.hourThree = hourThree;
	}

	public String getHourFour() {
		return hourFour;
	}

	public void setHourFour(String hourFour) {
		this.hourFour = hourFour;
	}

	

	public String getHourFive() {
		return hourFive;
	}

	public void setHourFive(String hourFive) {
		this.hourFive = hourFive;
	}

	public String getHourSeven() {
		return hourSeven;
	}

	public void setHourSeven(String hourSeven) {
		this.hourSeven = hourSeven;
	}

	public String getHourEight() {
		return hourEight;
	}

	public void setHourEight(String hourEight) {
		this.hourEight = hourEight;
	}

	
	public Client(Integer tId, String empId, Date tsDate, String hourOne,
			String hourTwo, String hourThree, String hourFour, String hourFive,
			String hourSix, String hourSeven, String hourEight) {
		super();
		this.tId = tId;
		this.empId = empId;
		this.tsDate = tsDate;
		this.hourOne = hourOne;
		this.hourTwo = hourTwo;
		this.hourThree = hourThree;
		this.hourFour = hourFour;
		this.hourFive = hourFive;
		this.hourSix = hourSix;
		this.hourSeven = hourSeven;
		this.hourEight = hourEight;
	}

	@Override
	public String toString() {
		return "Client [tId=" + tId + ", empId=" + empId + ", tsDate=" + tsDate
				+ ", hourOne=" + hourOne + ", hourTwo=" + hourTwo
				+ ", hourThree=" + hourThree + ", hourFour=" + hourFour
				+ ", hourFive=" + hourFive + ", hourSix=" + hourSix
				+ ", hourSeven=" + hourSeven + ", hourEight=" + hourEight + "]";
	}

	


}

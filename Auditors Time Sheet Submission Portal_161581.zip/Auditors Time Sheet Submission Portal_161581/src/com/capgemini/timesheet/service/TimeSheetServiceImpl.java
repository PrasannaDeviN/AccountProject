package com.capgemini.timesheet.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.timesheet.dao.ITimeSheetDAO;
import com.capgemini.timesheet.entity.Client;
import com.capgemini.timesheet.exception.AuditorException;


@Service("service")
@Transactional
public class TimeSheetServiceImpl implements ITimeSheetService{

	@Autowired
	ITimeSheetDAO dao;
	@Override
	public Integer timeSheetSubmission(Client client) throws AuditorException 
	{
		Integer id=dao.timeSheetSubmission(client);
		return id;
	}

	
	
	
	
	
	
	
	
	
	
	
}

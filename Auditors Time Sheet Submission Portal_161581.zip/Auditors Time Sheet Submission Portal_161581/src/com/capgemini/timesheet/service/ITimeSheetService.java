package com.capgemini.timesheet.service;

import com.capgemini.timesheet.entity.Client;
import com.capgemini.timesheet.exception.AuditorException;


public interface ITimeSheetService {

	public Integer timeSheetSubmission(Client client) throws AuditorException;

}
